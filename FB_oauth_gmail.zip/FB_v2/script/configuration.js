var modules = [{"nombre":"Trendinalia","codigo":"TRA", "isactive":false},
{"nombre":"Metabusiness","codigo":"MB", "isactive":false}];